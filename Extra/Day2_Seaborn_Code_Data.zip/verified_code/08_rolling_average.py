import pandas as pd
import seaborn as sns

sns.set_theme(style="whitegrid")

df = pd.read_csv("training_monthly.csv")
df["Month"] = pd.to_datetime(df["Month"])
df = df.sort_values("Month").copy()
df["Score_3M_Avg"] = df["Average_Score"].rolling(window=3).mean()

ax = sns.lineplot(
    data=df,
    x="Month",
    y="Average_Score",
    label="Monthly Score"
)
sns.lineplot(
    data=df,
    x="Month",
    y="Score_3M_Avg",
    label="3-Month Moving Average",
    ax=ax
)
ax.set(
    xlabel="Month",
    ylabel="Average Score",
    title="Monthly Score and 3-Month Moving Average"
)
ax.tick_params(axis="x", rotation=45)
ax.figure.tight_layout()
