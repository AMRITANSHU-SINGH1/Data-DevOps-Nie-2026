import pandas as pd
import seaborn as sns

sns.set_theme(style="whitegrid")

df = pd.read_csv("training_data.csv")

ax = sns.boxplot(data=df, y="Assessment_Score")
ax.set(
    ylabel="Assessment Score",
    title="Assessment Score Spread"
)
ax.figure.tight_layout()
