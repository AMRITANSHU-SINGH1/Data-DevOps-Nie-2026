Day 2 visualization examples migrated to Seaborn.
All plotting functions use Seaborn APIs; Matplotlib pyplot is not imported in the visualization scripts.
Seaborn itself is built on Matplotlib.
