import pandas as pd
import seaborn as sns

sns.set_theme(style="white")

df = pd.read_csv("training_data.csv")
numeric_df = df[
    ["Training_Hours", "Attendance_Percentage", "Assessment_Score"]
]

corr = numeric_df.corr()

ax = sns.heatmap(
    corr,
    annot=True,
    fmt=".2f",
    cmap="coolwarm"
)
ax.set_title("Training Metrics Correlation", pad=12)
ax.figure.tight_layout()
