import pandas as pd

df = pd.read_csv("training_data.csv")
numeric_df = df[
    ["Training_Hours", "Attendance_Percentage", "Assessment_Score"]
]

print(numeric_df.corr())
