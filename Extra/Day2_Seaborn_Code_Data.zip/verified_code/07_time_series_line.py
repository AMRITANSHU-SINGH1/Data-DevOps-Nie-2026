import pandas as pd
import seaborn as sns

sns.set_theme(style="whitegrid")

df = pd.read_csv("training_monthly.csv")
df["Month"] = pd.to_datetime(df["Month"])
df = df.sort_values("Month")

ax = sns.lineplot(
    data=df,
    x="Month",
    y="Average_Score",
    marker="o"
)
ax.set(
    xlabel="Month",
    ylabel="Average Score",
    title="Monthly Average Assessment Score"
)
ax.tick_params(axis="x", rotation=45)
ax.figure.tight_layout()
