import pandas as pd
import seaborn as sns

sns.set_theme(style="whitegrid")

df = pd.read_csv("training_data.csv")

ax = sns.histplot(
    data=df,
    x="Assessment_Score",
    bins=6,
    edgecolor="black",
    color=sns.color_palette()[0]
)
ax.set(
    xlabel="Assessment Score",
    ylabel="Number of Employees",
    title="Distribution of Assessment Scores"
)
ax.figure.tight_layout()
