import pandas as pd
import seaborn as sns

sns.set_theme(style="whitegrid")

df = pd.read_csv("training_data.csv")
plot_df = df[["Attendance_Percentage", "Assessment_Score"]].dropna()

ax = sns.scatterplot(
    data=plot_df,
    x="Attendance_Percentage",
    y="Assessment_Score"
)
ax.set(
    xlabel="Attendance (%)",
    ylabel="Assessment Score",
    title="Attendance vs Assessment Score"
)
ax.figure.tight_layout()
