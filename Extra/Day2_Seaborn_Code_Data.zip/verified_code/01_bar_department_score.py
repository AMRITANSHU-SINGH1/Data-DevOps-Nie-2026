import pandas as pd
import seaborn as sns

sns.set_theme(style="whitegrid")

df = pd.read_csv("training_data.csv")
df["Assessment_Score"] = df["Assessment_Score"].fillna(
    df["Assessment_Score"].median()
)
df["Department"] = df["Department"].fillna("Unknown")

summary = (
    df.groupby("Department", as_index=False)["Assessment_Score"]
      .mean()
      .sort_values("Assessment_Score", ascending=False)
)

ax = sns.barplot(
    data=summary,
    x="Department",
    y="Assessment_Score",
    hue="Department",
    palette="deep",
    legend=False
)
ax.set(
    xlabel="Department",
    ylabel="Average Assessment Score",
    title="Average Assessment Score by Department"
)
ax.tick_params(axis="x", rotation=30)
ax.figure.tight_layout()
