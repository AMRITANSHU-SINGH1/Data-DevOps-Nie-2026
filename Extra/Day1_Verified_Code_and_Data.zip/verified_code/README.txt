Day 1 verified code assets

All .py examples were AST-parsed and execution-tested against training_data.csv.
The code uses corrected versions where the supplied reference contained syntax/API issues.
