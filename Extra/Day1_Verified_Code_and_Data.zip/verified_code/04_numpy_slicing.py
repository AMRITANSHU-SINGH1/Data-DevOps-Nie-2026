import numpy as np

matrix = np.arange(1, 21).reshape(5, 4)

print("Matrix:")
print(matrix)

print("Second column:")
print(matrix[:, 1])

print("Rows 2 to 4:")
print(matrix[1:4, :])

print("Rows 2 to 5, columns 2 to 4:")
print(matrix[1:, 1:4])
