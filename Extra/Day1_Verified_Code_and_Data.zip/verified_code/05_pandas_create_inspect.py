import pandas as pd

data = {
    "Employee_ID": ["E001", "E002", "E003"],
    "Department": ["IT", "HR", "Finance"],
    "Assessment_Score": [85, 78, 92]
}

df = pd.DataFrame(data)

print(df)
print(df.head())
print(df.info())
print(df.describe())
