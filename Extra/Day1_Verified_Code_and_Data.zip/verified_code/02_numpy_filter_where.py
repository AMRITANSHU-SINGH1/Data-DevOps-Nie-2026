import numpy as np

week_spendings = np.array([50, 120, 30, 40, 200, 90, 300])

high_spend_indices = np.where(week_spendings > 100)[0]
high_spend_values = week_spendings[week_spendings > 100]

print("High-spend indices:", high_spend_indices)
print("High-spend values:", high_spend_values)
