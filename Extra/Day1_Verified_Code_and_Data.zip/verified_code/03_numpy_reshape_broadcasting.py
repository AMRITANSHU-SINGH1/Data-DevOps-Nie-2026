import numpy as np

arr = np.arange(1, 13)
matrix = arr.reshape(3, 4)

print("Matrix:")
print(matrix)
print("Shape:", matrix.shape)

adjusted_matrix = matrix + 5
print("After broadcasting +5:")
print(adjusted_matrix)
