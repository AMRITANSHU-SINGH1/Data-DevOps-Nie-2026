import numpy as np

training_scores = np.array([72, 85, 91, 64, 78, 88, 95])

print("Scores:", training_scores)
print("Mean:", training_scores.mean())
print("Maximum:", training_scores.max())
print("Index of maximum:", np.argmax(training_scores))
