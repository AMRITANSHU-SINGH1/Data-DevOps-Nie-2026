import pandas as pd

df = pd.read_csv("training_data.csv")

df["Assessment_Score"] = df["Assessment_Score"].fillna(
    df["Assessment_Score"].median()
)

df["Performance_Band"] = pd.cut(
    df["Assessment_Score"],
    bins=[-1, 59, 74, 89, 100],
    labels=["Needs Support", "Developing", "Proficient", "Excellent"]
)

print(
    df[
        ["Employee_ID", "Assessment_Score", "Performance_Band"]
    ].head()
)
