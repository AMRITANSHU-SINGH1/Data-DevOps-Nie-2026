import pandas as pd

df = pd.read_csv("training_data.csv")

print("Missing values before cleaning:")
print(df.isna().sum())

df["Department"] = df["Department"].fillna("Unknown")
df["Attendance_Percentage"] = df["Attendance_Percentage"].fillna(
    df["Attendance_Percentage"].median()
)
df["Assessment_Score"] = df["Assessment_Score"].fillna(
    df["Assessment_Score"].median()
)

df["Training_Date"] = pd.to_datetime(
    df["Training_Date"],
    errors="coerce"
)

summary = (
    df.groupby("Department", as_index=False)
      .agg(
          Avg_Score=("Assessment_Score", "mean"),
          Avg_Attendance=("Attendance_Percentage", "mean"),
          Employees=("Employee_ID", "count")
      )
)

print("\nMissing values after cleaning:")
print(df.isna().sum())

print("\nDepartment summary:")
print(summary)
