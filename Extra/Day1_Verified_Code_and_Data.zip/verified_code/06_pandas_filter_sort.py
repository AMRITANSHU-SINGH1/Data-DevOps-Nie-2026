import pandas as pd

df = pd.DataFrame({
    "Employee_ID": ["E001", "E002", "E003", "E004"],
    "Department": ["IT", "HR", "Finance", "IT"],
    "Assessment_Score": [85, 78, 92, 88]
})

high_performers = df[df["Assessment_Score"] >= 80]

top_performers = high_performers.sort_values(
    by="Assessment_Score",
    ascending=False
)

print(top_performers)
